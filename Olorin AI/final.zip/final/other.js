const firstName = 'Marcel';
console.log(months);
